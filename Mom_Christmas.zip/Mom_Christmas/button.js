function changeMe(){
    document.getElementById("button").innerHTML = "<p>You have won $1,000,000,000,000 in monopoly money!</p>";
}

