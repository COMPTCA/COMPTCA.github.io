﻿import sys
from cx_Freeze import setup, Executable
import os

PYTHON_INSTALL_DIR = os.path.dirname(os.path.dirname(os.__file__))
os.environ['TCL_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tcl8.6')
os.environ['TK_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tk8.6')

base = None
if sys.platform == 'win32' : base = 'Win32GUI'

opts = {
    'include_files' : ['lotto.gif',os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tk86t.dll'), \
                       os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tcl86t.dll'),] ,
    'includes' : ['re'],
    'excludes' : ['Tkinter']}

setup(name = 'Lotto' ,
      version = '1.0' ,
      description = 'Lottery Number Picker' ,
      author = 'Cole Compton' ,
      options = {'build_exe' : opts, } ,
      executables = [ Executable( 'lotto.py' , base = base) ] )
