function myFunction(){
	document.getElementById("p").innerHTML = Date();
}
myFunction();